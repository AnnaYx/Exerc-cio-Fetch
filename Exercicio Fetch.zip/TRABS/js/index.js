function gravar()
{
    var form = document.getElementById('formcadastro');
    var dados = new FormData(form);
    var senha = document.getElementById("Senha").value;
    var  ConfirmarSenha = document.getElementById('ConfirmarSenha').value;

    if (senha != ConfirmarSenha){
        alert('as senhas não comdizem. Bote a mesma senha nos dois campos');
        document.getElementById('Senha').value = ""
        document.getElementById('ConfirmarSenha').value = ""

    }
    else{
        fetch("php/gravar.php", {
            method: "POST",
            body: dados
        });
    }   
}


